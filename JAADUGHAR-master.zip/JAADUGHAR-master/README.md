<h2 align="center">
    ─────「✨     KSK ✘ ᴍᴜsɪᴄ ✨」─────
</h2>

<p align="center">
  <img src="https://telegra.ph/file/3e81d08db1a144c6a2f6b.jpg">
</p>

<h3 align="center">
 ᴛʜᴇ ᴍᴏsᴛ ғᴀsᴛ ᴀɴᴅ ᴩᴏᴡᴇʀғᴜʟ ᴍᴜsɪᴄ ᴩʟᴀʏᴇʀ ʙᴏᴛ
</h3>
<h2 align="center">
━━━━━━━━━━━━━━━━━━━━
</h2>

<p align="center">
<a href="https://github.com/AnonymousR1025/Fallen-Music/stargazers"><img src="https://img.shields.io/github/stars/AnonymousR1025/Fallen-Music?color=black&logo=github&logoColor=black&style=for-the-badge" alt="Stars" /></a>
<a href="https://github.com/AnonymousR1025/Fallen-Music/network/members"> <img src="https://img.shields.io/github/forks/AnonymousR1025/Fallen-Music?color=black&logo=github&logoColor=black&style=for-the-badge" /></a>
<a href="https://github.com/AnonymousR1025/Fallen-Music/blob/master/LICENSE"> <img src="https://img.shields.io/badge/License-MIT-blueviolet?style=for-the-badge" alt="License" /> </a>
<a href="https://www.python.org/"> <img src="https://img.shields.io/badge/Written%20in-Python-skyblue?style=for-the-badge&logo=python" alt="Python" /> </a>
<a href="https://github.com/AnonymousR1025/Fallen-Music/commits/AnonymousR1025"> <img src="https://img.shields.io/github/last-commit/AnonymousR1025/Fallen-Music?color=black&logo=github&logoColor=black&style=for-the-badge" /></a>
</p>

<h2 align="center">
━━━━━━━━━━━━━━━━━━━━
</h2>

<p align="center">
  <img src="https://telegra.ph/file/018fbdef43c96ca2092fc.jpg">
</p>

<p align="center">
<b>𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</b>
</p>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>
<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/Rahulsharma45/EVERYONExKSK"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
<h2 align="center">
──────────
</h2>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ᴏᴋᴛᴇᴛᴏ 」─
</h3>
<p align="center"><a href="https://cloud.okteto.com/deploy?repository=https://github.com/AnonymousR1025/Fallen-Music"><img src="https://img.shields.io/badge/Deploy%20On%20Okteto-informational?style=for-the-badge&logo=Okteto" width="200" height="35.45"/></a></p>

<h2 align="center">
━━━━━━━━━━━━━━━━━━━━
</h2>

<h3 align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</h3>

<p align="center">
<a href="https://telegram.me/DevilsHeavenMF"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>
<p align="center">
<a href="https://telegram.me/FallenXBots"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

- **ᴛʜᴀɴᴋꜱ ᴛᴏ [ᴛʜᴇ ᴄᴏɴᴛʀɪʙᴜᴛᴏʀs](https://github.com/AnonymousR1025/Fallen-Music/graphs/contributors) ᴡʜᴏ ʜᴇʟᴩᴇᴅ ɪɴ ᴍᴀᴋɪɴɢ ғᴀʟʟᴇɴ ✘ ᴍᴜsɪᴄ 🖤**

----------------------------------------------------------
